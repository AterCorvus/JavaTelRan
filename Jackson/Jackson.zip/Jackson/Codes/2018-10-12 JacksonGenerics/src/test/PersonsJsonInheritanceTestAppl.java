package test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import dto.Address;
import dto.Person;


public class PersonsJsonInheritanceTestAppl {

	public static void main(String[] args) throws Exception {
		
		ArrayList<Person> arrayListPersonsInitial = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		
		mapper.registerModule(new JavaTimeModule());
		
		Person p1 = new Person(124, new Address("Rehovot", "Plaut"), "Moshe", LocalDate.of(1970, 1, 10));
		Person p2 = new Person(123, new Address("Lod", "Vaizman"), "Vasya", LocalDate.of(2014, 5, 12));
		arrayListPersonsInitial.add(p1);
		arrayListPersonsInitial.add(p2);
		
		ObjectWriter ow = mapper.writerFor(new TypeReference<ArrayList<Person>>() {});
		String jsonPerson = ow.writeValueAsString(arrayListPersonsInitial);
		System.out.println(jsonPerson);
		
		ArrayList<Person> arrayListPersonsResult = mapper.readValue(jsonPerson, new TypeReference<ArrayList<Person>>() {});	
		
		for (Person person : arrayListPersonsResult) System.out.println(person);
	}

}
