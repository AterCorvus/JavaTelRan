package telran.cars.dto;

public enum CarsReturnCode {
OK,NO_MODEL,MODEL_EXISTS,CAR_EXISTS,DRIVER_EXISTS, NO_CAR, CAR_IN_USE, NO_DRIVER, CAR_REMOVED
}
