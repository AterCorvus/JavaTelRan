package telran.cars.dto;

public enum State {
EXCELLENT,GOOD,BAD
}
